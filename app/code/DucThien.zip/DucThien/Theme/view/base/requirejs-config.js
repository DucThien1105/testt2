var config = {
    config: {
        mixins: {
            'Magento_PageBuilder/js/content-type/products/appearance/carousel/widget': {
                'DucThien_Theme/js/content-type/products/appearance/carousel/widget-mixin': true
            }
        }
    }
};

